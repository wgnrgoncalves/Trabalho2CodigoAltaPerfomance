package br.com.fiap.codigoaltaperformance.tabalho02.atendimento;

public class Estatico {
	public static String[] sintomas = new String[] {"Sem Sintomas", "febre","tosse seca","cansa�o","dores e desconfortos","dor de garganta","diarreia","conjuntivite","dor de cabe�a","perda de paladar ou olfato","erup��o cut�nea na pele ou descolora��o dos dedos das m�os ou dos p�s","dificuldade de respirar ou falta de ar","dor ou press�o no peito","perda de fala ou movimento"};
}
